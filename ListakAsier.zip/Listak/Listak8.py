'''
17/12/2020 Asier Blazquez
Write a Python program to clone or copy a list.
'''


list= [1,2,2,3,4,5]


newlist= list;

print(newlist)