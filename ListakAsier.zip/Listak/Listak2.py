'''
11/12/2020 Asier Blazquez

Write a Python program to multiplies all the items in a list.

'''

list= [1,2,3,4,5]
mult =1;
for i in list:
    mult= mult*i
print(mult)