'''
11/12/2020 Asier Blazquez

Write a Python program to sum all the items in a list.

'''

list= [1,2,3,4,5]
sum =0;
for i in list:
    sum= sum+i
print(sum)