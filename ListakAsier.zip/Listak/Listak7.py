'''
17/12/2020 Asier Blazquez
Write a Python program to remove duplicates from a list. '''


list= []

if (len(list)==0):
    print("lista hutsik dago")
else:
    print("lista beteta dago")