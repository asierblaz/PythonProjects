'''
11/12/2020 Asier Blazquez

Write a Python program to get the smallest number from a list.
'''

list= [1,2,3,4,5]

list.sort()

print(list[0])