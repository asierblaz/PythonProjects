'''
17/12/2020 Asier Blazquez
Write a Python program to remove duplicates from a list.
'''


list= ['a','e','e','i','o']

list2=[]
cont = 0
for cont,i in enumerate(list):
    print(cont)
