'''
17/12/2020 Asier Blazquez
Write a Python program access the index of a list'''


list = [2, 4, 6, 8]
for cont, val in enumerate(list):
    print(cont, val)