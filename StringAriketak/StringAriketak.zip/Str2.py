'''
08/01/2021 Asier Blazquez

2.	A partir de un string y un caracter y retorne un int que represente el número de apariciones del caracter en el string.
'''

texto= "Cuantas a's hay en este texto?"

print('Hay ', texto.count('a'), 'en el texto')