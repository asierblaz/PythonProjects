'''
08/01/2021 Asier Blazquez

4.	A partir de dos parámetros, s, original y reemplazo, que reemplace las apariciones del string original en s por reemplazo'''

texto= "SD Eibar partidua galdu du"

print(texto)

texto2 = texto.replace("galdu", "irabazi")
print(texto2)
