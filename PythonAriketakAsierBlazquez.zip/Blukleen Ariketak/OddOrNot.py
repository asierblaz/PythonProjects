'''
03/12/2020 Asier Blazquez

Make a program that asks a number and says if it is odd or not.
'''

n= int(input("Sartu zenbaki bat bakoitia edo bikoitia den jakiteko: "))

if(n%2==0):
    print(n,"Bikoitia da")
else:
    print(n,"Bakoitia da")
