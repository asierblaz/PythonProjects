'''
08/12/2020 Asier Blazquez


Write a Python program to construct the following pattern, using a nested loop number.

'''

for i in range(1,10):
    for j in range(i):
        print(i, end="")
    print('')